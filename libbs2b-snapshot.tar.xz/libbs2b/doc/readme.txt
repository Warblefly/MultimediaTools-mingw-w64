Online and downloadable description is available
at http://bs2b.sourceforge.net/
