Win32 library of libsndfile v1.0.20.

libsndfile is copyright by Erik de Castro Lopo.
http://www.mega-nerd.com/libsndfile/
