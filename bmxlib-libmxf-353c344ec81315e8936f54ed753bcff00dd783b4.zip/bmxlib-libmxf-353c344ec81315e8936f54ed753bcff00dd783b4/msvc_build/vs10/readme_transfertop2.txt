The transfertop2 code requires the AAF SDK (http://aaf.sourceforge.net). 

Download the AAF SDK development libraries (AAF-devel-libs) for windows
and set the AAFSDKINSTALL environment variable to point the installation 
directory.
